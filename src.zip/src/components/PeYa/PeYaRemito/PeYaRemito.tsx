import React, { useEffect, useMemo, useState } from "react";
import type { Destino } from "../../../core/remitos/Destino";
import { loadPeyaDestinos } from "../../../services/peya/PeyaDestinosService";
import { useLocation } from "react-router-dom";
import styles from "../PeYaRemito/PeYaRemito.module.css";
import type { Remito } from "../../../core/remitos/Remito";
import RemitoDocument from "../../../services/remito/RemitoDocument";
import { SOURCE_OFFICES } from "../../../core/remitos/RemitoConfig";
import { getPeyaBranch } from "../../PeYa/utils/peyaBranch";


interface Producto {
  sku: string;  
  ean: string;
  producto: string;
  uxb: string;
  bultos: number;
  unidades: number;
}

interface RemitoData {
  st: string;
  sku: string;
  ean: string;
  title: string;
  uxb: string;
  bultos: number;
  unidades: number;
  storeName: string;
}
interface RemitoPrintState {
    data?: RemitoData[];
    remitos?: {st: string; remito: string;}[];
    remitosGenerados?: Remito[];
}


const COPIAS = [
  "──────── ORIGINAL ────────",
  "─────── DUPLICADO ───────",
  "────── TRIPLICADO ──────"
] as const;

const MAX_ITEMS = 24;

const PeYaRemito: React.FC = () => {
const [destinos, setDestinos] = useState<Record<string, Destino> | null>(null);
const [destinosError, setDestinosError] = useState<string | null>(null);
useEffect(() => {
  const cargarDestinos = async () => {
    try {
      const data = await loadPeyaDestinos();
      setDestinos(data);
    } catch (error) {
      console.error("Error cargando destinos PeYa:", error);

      setDestinosError(
        "No fue posible cargar la base de destinos PeYa."
      );
    }
  };

  cargarDestinos();
}, []);
const branch = getPeyaBranch();
const sourceOffice = SOURCE_OFFICES[branch];
const location = useLocation();
const state = location.state as RemitoPrintState | null;
const storedData = sessionStorage.getItem("peya-remito-print-data");
const sessionData: RemitoPrintState | null = storedData ? JSON.parse(storedData) as RemitoPrintState : null;
const data = state?.data ?? sessionData?.data ?? [];
const remitos = state?.remitos ?? sessionData?.remitos ?? [];
const remitosGenerados = state?.remitosGenerados ?? sessionData?.remitosGenerados ?? [];
const regexST = /^ST[A-Z0-9]\d+$/;
const groupedByST = useMemo(() => {
  const groups: Record<string, RemitoData[]> = {};
    data.forEach(row => {
      if (!row.st || !regexST.test(row.st)) return;
      if (!groups[row.st]) {
        groups[row.st] = [];
      }
      groups[row.st].push(row);
    });
    return groups;
  }, [data]);

  const remitosMap=useMemo(()=>{
      return new Map(
          remitos.map(r=>[
              r.st,
              r.remito
          ])
      );
  },[remitos]);

  const stKeys = useMemo(() => Object.keys(groupedByST).sort(),[groupedByST]);
  const fechaEmision = useMemo(() => new Intl.DateTimeFormat("es-AR").format(new Date()),[]);
  const completarProductos = (productos: Producto[]) => {
    const lista = [...productos];
    while (lista.length < MAX_ITEMS) {
      lista.push({
        sku: "",
        ean: "",
        producto: "",
        uxb: "",
        bultos: 0,
        unidades: 0
      });
    }
    return lista;
  };
  const dividirEnPaginas = (productos: Producto[]): Producto[][] => {
      const paginas: Producto[][] = [];
      for (let i = 0; i < productos.length; i += MAX_ITEMS) {
          paginas.push(productos.slice(i, i + MAX_ITEMS));
      }
      return paginas;
  };

  const imprimir = () => {
    window.print();
  };

  if (remitosGenerados.length > 0) {
    return (
        <>
            <div className={styles.topActions}>
                <button className={styles.printButton} onClick={imprimir}>
                    Imprimir
                </button>
            </div>
            {remitosGenerados.map(remito => (
                <RemitoDocument
                    key={remito.numero}
                    remitos={[remito]}
                />
            ))}
        </>
    );
  }
  if (destinosError) {
  return (
    <div>
      <strong>{destinosError}</strong>
    </div>
  );
}

if (!destinos) {
  return (
    <div>
      Cargando destinos...
    </div>
  );
}

  return (
        <>
      <div className={styles.topActions}>
        <button className={styles.printButton} onClick={imprimir}>
          Imprimir
        </button>
      </div>

      {stKeys.map((st) => {
        const numeroRemito=
        remitosMap.get(st)??"";
        const currentRows = groupedByST[st];
        const storeName = currentRows[0]?.storeName ?? "";
        const destino = destinos[storeName] ?? {
          domicilio: "",
          localidad: "",
          cp: ""
        };

        const productos: Producto[] = currentRows.map((r) => ({
          sku: String(r.sku ?? ""),
          ean: String(r.ean ?? ""),
          producto: String(r.title ?? ""),
          uxb: String(r.uxb ?? ""),
          bultos: Number(r.bultos) || 0,
          unidades: Number(r.unidades) || 0
        }));

        const paginas = dividirEnPaginas(productos);
        const totalPaginas = paginas.length;
        const totalBultos = productos.reduce((acc, p) => acc + p.bultos, 0);
        const totalUnidades = productos.reduce((acc, p) => acc + p.unidades, 0);
        
  return COPIAS.flatMap((copia) => paginas.map((productosPagina, pageIndex) => {
    const productosConBlancos = completarProductos(productosPagina);
    const subtotalPaginaBultos = productosPagina.reduce((acc, p) => acc + p.bultos, 0);
    const subtotalPaginaUnidades = productosPagina.reduce((acc, p) => acc + p.unidades, 0);
    return (
        <div
          key={`${st}-${copia}-${pageIndex}`}
          className={styles.remito}
        >
          <div className={styles.container}>
              <div className={styles.verticalMark}>
                <div className={styles.verticalText}>
                  {copia}
                </div>
              </div>
              <div className={styles.header}>
                <div className={styles.leftBox}>
                  <p>Organización Courier Argentina S.A (OCASA)</p>
                  <p>R.N.P.S.P N° 731</p>
                  <p>Echeverría 1262/64 - C1428DQN - Capital Federal</p>
                  <p>I.V.A.: RESPONSABLE INSCRIPTO</p>
                </div>

                <div className={styles.centerBox}>
                  <span className={styles.bigR}>R</span>
                </div>

                <div className={styles.rightBox}>
                  <p>Remito Nº: {numeroRemito}</p>
                  <p className={styles.barcode}>
                    *{numeroRemito}*
                  </p>
                  <p>Fecha de Emisión: {fechaEmision}</p>
                  <p>C.U.I.T. Nº 30-66204961-8</p>
                  <p>Ingresos Brutos Nº 901995900-0</p>
                  <p>Inicio de Actividades: 01/07/1993</p>
                </div>
              </div>

              <div className={styles.body}>
                <div className={styles.leftSection}>
                  <p>Por cuenta y orden de: DELIVERY HERO E-COMMERCE S.A.</p>
                  <p>Solic: 102003550 - AP: 40044001 / 10</p>
                  <p>Domicilio: JUSTO JUAN B AV. 637</p>
                  <p>Código Postal: 1425</p>
                  <p>Localidad: Capital Federal</p>

                  <hr />

                  <p>Detalles de Origen - {sourceOffice.office}</p>
                  <p>Domicilio: {sourceOffice.adress}</p>
                  <p>Código Postal: {sourceOffice.zipCode}</p>
                  <p>Localidad: {sourceOffice.state}</p>

                  <hr />

                  <p>
                    Detalles de entrega - Pedido Nº:
                    <strong> {st}</strong>
                  </p>
                  <p>
                    Destinatario:
                    <strong> {storeName}</strong>
                  </p>
                  <p>
                    Domicilio:
                    <strong> {destino.domicilio}</strong>
                  </p>

                  <p>
                    Localidad:
                    <strong> {destino.localidad}</strong>
                    {"  "}
                    CP:
                    <strong> {destino.cp}</strong>
                  </p>

                  <p>
                    Guía Remito:
                    <strong> {st}</strong>
                  </p>

                  <hr />
                </div>

                <div className={styles.rightSection}>
                  <p className={styles.barcodeLarge}>
                    *{st}*
                  </p>

                  <p className={styles.guiaRemito}>
                    {st}
                  </p>
                </div>
              </div>

              {/* Tercera parte */}
                <div className={styles.terceraParte}>
                        <p className={styles.leyenda}>
                  Remitimos a UD.(es) lo siguiente
                </p>
                <hr />
                <table className={styles.productosTable}>
                  <thead>
                    <tr>
                      <th>SKU</th>
                      <th>EAN</th>
                      <th>Producto</th>
                      <th>UxB</th>
                      <th>Bultos</th>
                      <th>Unidades</th>
                    </tr>
                  </thead>

                  <tbody>
                    {productosConBlancos.map((p, index) => (
                      <tr key={index}>
                        <td>
                          <strong>{p.sku}</strong>
                        </td>

                        <td>{p.ean}</td>

                        <td title={p.producto}>
                          <span className={styles.productoTexto}>
                            {p.producto}
                          </span>
                        </td>

                        <td>{p.uxb}</td>

                        <td>
                          <strong>
                            {p.bultos > 0 ? p.bultos : ""}
                          </strong>
                        </td>

                        <td>
                          {p.unidades > 0 ? p.unidades : ""}
                        </td>
                      </tr>
                    ))}

{totalPaginas === 1 ? (
    <tr className={styles.totalRow}>
        <td colSpan={4}>
            <strong>Total</strong>
        </td>

        <td>
            <strong>{totalBultos}</strong>
        </td>

        <td>
            <strong>{totalUnidades}</strong>
        </td>
    </tr>
) : (
    <>
        <tr className={styles.totalRow}>
            <td colSpan={4}>
                <strong>Sub-total de página</strong>
            </td>

            <td>
                <strong>{subtotalPaginaBultos}</strong>
            </td>

            <td>
                <strong>{subtotalPaginaUnidades}</strong>
            </td>
        </tr>

        {pageIndex === totalPaginas - 1 && (
              <tr className={styles.totalRow}>
                  <td colSpan={4}>
                      <strong>Total</strong>
                  </td>

                  <td>
                      <strong>{totalBultos}</strong>
                  </td>

                  <td>
                      <strong>{totalUnidades}</strong>
                  </td>
              </tr>
              )}
            </>
          )}
                  </tbody>
                </table>
              </div>
              {/* Sección de firmas y recepción */}
              <div className={styles.footer}>
                <div className={styles.footerTitle}>
                  CONFORME DE RECEPCIÓN
                </div>

                <div className={styles.footerContent}>
                  <div className={styles.firmasBox}>
                    <p className={styles.footerHeading}>
                      <strong>Entrega (Chofer)</strong>
                    </p>

                    <div className={styles.footerSpacer}></div>

                    <p className={styles.footerP}>Firma</p>

                    <div className={styles.footerSpacer}></div>

                    <p>
                      Aclaración
                      <span className={styles.fechaHora}>
                        Fecha y Hora
                      </span>
                    </p>
                  </div>

                  <div className={styles.footerRight}>
                    <p className={styles.footerHeading}>
                      <strong>Recibe</strong>
                    </p>

                    <div className={styles.footerSpacer}></div>

                    <p className={styles.footerP}>
                      Firma / Sello
                    </p>

                    <div className={styles.footerSpacer}></div>

                    <p>
                      Aclaración
                      <span className={styles.fechaHora}>
                        Fecha y Hora
                      </span>
                    </p>
                  </div>
                </div>

                <div className={styles.footerBottom}>
                  <span className={styles.footerLeft}>
                    CAI N° 52388220598334 &nbsp;&nbsp;&nbsp;
                    Fecha de Vto: 20.03.2027
                  </span>

                  <span className={styles.footerRightText}>
                    Hoja {pageIndex + 1} de {totalPaginas}
                  </span>              
                </div>
              </div>
            </div>
          </div>
        );
      }));
    })}
  </>
  );
};

export default PeYaRemito;
import { useEffect, useMemo, useState } from "react";
import { InventarioSummaryBuilder } from "../inventarios/InventarioSummaryBuilder";
import { InventarioWeeklyBuilder } from "../inventarios/InventarioWeeklyBuilder";
import styles from "./PeYaInventariosInforme.module.css";
import InventarioWeeklyChart from "./InventarioWeeklyChart";
import AnimatedNumber from "../../../../utils/AnimatedNumber";
import { usePeYaInventariosData } from "../inventarios/hooks/usePeYaInventariosData";

interface MesDisponible {
    key: string;
    year: number;
    month: number;
    label: string;
}

const PeYaInventariosInforme = () => {
    const {inventarios, feriados, fechaActualizacion, loading, error} = usePeYaInventariosData();
    const [selectedMonth, setSelectedMonth] = useState("");

    /* =========================================
       MESES DISPONIBLES
       ========================================= */
    const mesesDisponibles = useMemo(() => {
        const meses = new Map< string, MesDisponible >();
        inventarios.forEach(item => {
            if (Number.isNaN(item.fecha.getTime())) {
                return;
            }
            const year = item.fecha.getFullYear();
            const month = item.fecha.getMonth();
            const key = `${year}-${month}`;
            if (!meses.has(key)) {
                const rawLabel = new Intl.DateTimeFormat("es-AR", {month: "long", year: "numeric"}
                    ).format(item.fecha );
                const label = rawLabel.charAt(0).toUpperCase() + rawLabel.slice(1);
                meses.set(key,{key, year, month, label}
                );
            }
        });
        return [...meses.values()].sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);
    }, [inventarios]);

    const fechaActualizacionTexto = fechaActualizacion ? fechaActualizacion.toLocaleDateString(
            "es-AR", {day: "2-digit", month: "2-digit", year: "numeric"}) : "";
    /* =========================================
       MES INICIAL
       ========================================= */
    useEffect(() => {
        if (mesesDisponibles.length === 0 || selectedMonth) {
            return;
        }
        const hoy = new Date();
        const keyActual = `${hoy.getFullYear()}-${hoy.getMonth()}`;
        const mesActual = mesesDisponibles.find(mes => mes.key === keyActual);
        if (mesActual) {
            setSelectedMonth(mesActual.key);
            return;
        }
        /*
         * Si el archivo no contiene el mes actual,
         * seleccionamos el último disponible.
         */
        const ultimo = mesesDisponibles[mesesDisponibles.length - 1];
        setSelectedMonth(ultimo.key);
    }, [mesesDisponibles, selectedMonth]);

    /* =========================================
       PERÍODO SELECCIONADO
       ========================================= */
    const periodo = useMemo(() => {
        const mes = mesesDisponibles.find( item => item.key === selectedMonth);
        if (!mes) {
            return null;
        }
        const desde = new Date(mes.year, mes.month, 1);
        const hasta = new Date(mes.year, mes.month + 1, 0, 23, 59, 59, 999);
        return {desde, hasta, mes};
    }, [mesesDisponibles, selectedMonth]);

    /* =========================================
       RESUMEN DEL MES
       ========================================= */
    const resumen = useMemo(() => {
        if (!periodo) {
            return null;
        }
        return InventarioSummaryBuilder.build(
            inventarios, feriados, periodo.desde, periodo.hasta, fechaActualizacion);
    }, [inventarios, feriados, periodo, fechaActualizacion]);

    /* =========================================
       DATOS SEMANALES
       ========================================= */
    const datosSemanales = useMemo(() => {
        if (!periodo) {
            return [];
        }
        return InventarioWeeklyBuilder.build(
            inventarios, feriados, periodo.desde, periodo.hasta, fechaActualizacion);
    }, [inventarios, feriados, periodo, fechaActualizacion]);

    /* =========================================
       ESTADOS
       ========================================= */
    if (loading) {
        return (<div className={styles.message}>Cargando informe de inventarios...</div>);
    }
    if (error) {
        return (<div className={styles.error}>{error}</div>);
    }
    if (!resumen || !periodo) {
        return (<div className={styles.message}>No hay información disponible.</div>);
    }
    let diferencias = 0;
    if (resumen.realizados > 0) {
        diferencias = (resumen.conDiferencias / resumen.realizados) * 100;
    }
    const target = resumen.realizados - resumen.esperados;
    /* =========================================
       RENDER
       ========================================= */
    return (
        <div className={styles.container}>
            {/* SELECTOR */}
            <div className={styles.controls}>
                <select value={selectedMonth} onChange={event => setSelectedMonth(event.target.value)}>
                    {mesesDisponibles.map(mes => (<option key={mes.key} value={mes.key}>{mes.label}</option>))}
                </select>                
            </div>

            {/* TITULO */}
            <h2 className={styles.title}>
                Inventarios{" "} {periodo.mes.label}
            </h2>
            {fechaActualizacion  && (
                <div className={styles.lastUpdate}>
                    (última actualización{" "}{fechaActualizacionTexto})
                </div>
            )}
            {/* METRICAS */}
            <div className={styles.metricsGrid}>
                <div className={styles.metric}>
                    <strong><AnimatedNumber value={resumen.realizados} /></strong>
                    <span>Inventarios realizados</span>
                </div>
                <div className={styles.metric}>
                    <strong><AnimatedNumber value={resumen.sinDiferencias} /></strong>
                    <span>Sin diferencias</span>
                </div>
                <div className={styles.metric}>
                    <strong><AnimatedNumber value={resumen.conDiferencias} /></strong>
                    <span>Con diferencias</span>
                </div>
                <div className={styles.metric}>                    
                    <strong>
                        <AnimatedNumber value={diferencias} decimals={1} suffix="%" />
                    </strong>
                    <span>% de desvio</span>
                </div>
                {/* segunda linea */}
                <div className={styles.metric}>
                    <strong><AnimatedNumber value={resumen.diasLaborables}/></strong>
                    <span>Días laborables</span>
                </div>
                <div className={styles.metric}>
                    <strong><AnimatedNumber value={resumen.esperados}/></strong>
                    <span>Inventarios esperados</span>
                </div>
                <div className={`${styles.metric} ${target < 0 ? styles.metricWarning : ""}`} >
                    <strong><AnimatedNumber value={target} prefix={target > 0 ? "+" : ""} /></strong>
                    <span>Target</span>
                </div>
                <div className={styles.metric}>
                    <strong>
                        <AnimatedNumber value={resumen.cumplimiento} decimals={1} suffix="%" />
                    </strong>
                    <span>
                        Cumplimiento
                    </span>
                </div>
            </div>
            <button type="button" className={styles.coverageButton} onClick={() =>
                    window.open("/PeYaInformes/inventarios/cobertura", "_blank")}>
                <span className={styles.coverageButtonIcon}>📈</span>
                <span className={styles.coverageButtonContent}>
                    <strong>Ver avance de inventarios</strong>
                    <small>porcentaje inventariado del almacén</small>
                </span>                
            </button>
            {/* TEMPORALMENTE PARA VALIDAR
                EL CALCULO SEMANAL */}
            <InventarioWeeklyChart data={datosSemanales} />
        </div>
    );
};


export default PeYaInventariosInforme;
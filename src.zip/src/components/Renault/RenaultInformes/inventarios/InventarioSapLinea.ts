export interface InventarioSapLinea {
    id: number;
    documento: string;
    statusInventario: string;
    fecha: Date;
    referencia: string;
    posicion: string;
    material: string;
    descripcion: string;
    stockCantidad: number;
    stockValor: number;
    diferenciaCantidad: number;
    diferenciaValor: number;
    diferenciaValorAbsoluto: number;
    origen: "ZSAPPR110" | "LINV_VACIA";
}